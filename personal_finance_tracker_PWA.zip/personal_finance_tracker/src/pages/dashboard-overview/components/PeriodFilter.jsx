import React from 'react';
import Select from '../../../components/ui/Select';

const PeriodFilter = ({ selectedPeriod, onPeriodChange }) => {
  const currentYear = new Date()?.getFullYear();
  const months = [
    { value: '01', label: 'Januari' },
    { value: '02', label: 'Februari' },
    { value: '03', label: 'Maret' },
    { value: '04', label: 'April' },
    { value: '05', label: 'Mei' },
    { value: '06', label: 'Juni' },
    { value: '07', label: 'Juli' },
    { value: '08', label: 'Agustus' },
    { value: '09', label: 'September' },
    { value: '10', label: 'Oktober' },
    { value: '11', label: 'November' },
    { value: '12', label: 'Desember' }
  ];

  const years = [];
  for (let i = currentYear; i >= currentYear - 5; i--) {
    years?.push({ value: i?.toString(), label: i?.toString() });
  }

  const periodOptions = [
    { value: 'current-month', label: 'Bulan Ini' },
    { value: 'last-month', label: 'Bulan Lalu' },
    { value: 'current-year', label: 'Tahun Ini' },
    { value: 'last-year', label: 'Tahun Lalu' },
    { value: 'all-time', label: 'Semua Waktu' },
    ...months?.map(month => ({
      value: `${currentYear}-${month?.value}`,
      label: `${month?.label} ${currentYear}`
    })),
    ...years?.slice(1)?.map(year => ({
      value: year?.value,
      label: `Tahun ${year?.label}`
    }))
  ];

  return (
    <div className="mb-4">
      <Select
        label="Periode"
        options={periodOptions}
        value={selectedPeriod}
        onChange={onPeriodChange}
        placeholder="Pilih periode"
        className="w-full sm:w-64"
      />
    </div>
  );
};

export default PeriodFilter;