import React from 'react';
import { Link } from 'react-router-dom';
import Button from '../../../components/ui/Button';

const QuickActions = () => {
  const quickActionItems = [
    {
      title: 'Tambah Pemasukan',
      description: 'Catat pemasukan baru',
      icon: 'Plus',
      variant: 'default',
      to: '/add-transaction?type=pemasukan'
    },
    {
      title: 'Tambah Pengeluaran',
      description: 'Catat pengeluaran baru',
      icon: 'Minus',
      variant: 'outline',
      to: '/add-transaction?type=pengeluaran'
    },
    {
      title: 'Lihat Riwayat',
      description: 'Lihat semua transaksi',
      icon: 'History',
      variant: 'secondary',
      to: '/transaction-history'
    }
  ];

  return (
    <div className="bg-card rounded-lg border border-border p-4">
      <h3 className="text-lg font-semibold text-card-foreground mb-4">
        Aksi Cepat
      </h3>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {quickActionItems?.map((action, index) => (
          <Link key={index} to={action?.to} className="block">
            <Button
              variant={action?.variant}
              iconName={action?.icon}
              iconPosition="left"
              fullWidth
              className="h-auto p-4 flex-col items-start text-left"
            >
              <div className="font-medium text-sm mb-1">{action?.title}</div>
              <div className="text-xs opacity-70">{action?.description}</div>
            </Button>
          </Link>
        ))}
      </div>
    </div>
  );
};

export default QuickActions;