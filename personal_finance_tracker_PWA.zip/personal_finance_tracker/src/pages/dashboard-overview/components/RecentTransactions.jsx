import React from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../../components/AppIcon';

const RecentTransactions = ({ transactions }) => {
  const formatCurrency = (value) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    })?.format(value);
  };

  const formatDate = (date) => {
    return new Intl.DateTimeFormat('id-ID', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    })?.format(new Date(date));
  };

  const getCategoryIcon = (category) => {
    const iconMap = {
      'Makanan': 'UtensilsCrossed',
      'Transportasi': 'Car',
      'Belanja': 'ShoppingBag',
      'Hiburan': 'Gamepad2',
      'Kesehatan': 'Heart',
      'Pendidikan': 'BookOpen',
      'Gaji': 'Banknote',
      'Bonus': 'Gift',
      'Investasi': 'TrendingUp',
      'Freelance': 'Laptop',
      'Lainnya': 'MoreHorizontal'
    };
    return iconMap?.[category] || 'Circle';
  };

  const getTransactionColor = (type) => {
    return type === 'pemasukan' ? 'text-emerald-600' : 'text-red-600';
  };

  const getTransactionBg = (type) => {
    return type === 'pemasukan' ? 'bg-emerald-50' : 'bg-red-50';
  };

  return (
    <div className="bg-card rounded-lg border border-border p-4">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-card-foreground">
          Transaksi Terbaru
        </h3>
        <Link 
          to="/transaction-history"
          className="text-sm text-primary hover:text-primary/80 font-medium flex items-center space-x-1"
        >
          <span>Lihat Semua</span>
          <Icon name="ChevronRight" size={16} />
        </Link>
      </div>
      <div className="space-y-3">
        {transactions?.length === 0 ? (
          <div className="text-center py-8">
            <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-3">
              <Icon name="Receipt" size={24} color="#64748B" />
            </div>
            <p className="text-muted-foreground text-sm">Belum ada transaksi</p>
            <Link 
              to="/add-transaction"
              className="text-primary hover:text-primary/80 text-sm font-medium mt-2 inline-block"
            >
              Tambah transaksi pertama
            </Link>
          </div>
        ) : (
          transactions?.map((transaction) => (
            <div 
              key={transaction?.id}
              className="flex items-center space-x-3 p-3 rounded-lg hover:bg-muted/50 transition-colors duration-150"
            >
              <div className={`p-2 rounded-full ${getTransactionBg(transaction?.type)}`}>
                <Icon 
                  name={getCategoryIcon(transaction?.category)} 
                  size={20} 
                  color={transaction?.type === 'pemasukan' ? '#059669' : '#DC2626'}
                />
              </div>
              
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-medium text-card-foreground truncate">
                    {transaction?.description || transaction?.category}
                  </p>
                  <p className={`text-sm font-semibold ${getTransactionColor(transaction?.type)}`}>
                    {transaction?.type === 'pemasukan' ? '+' : '-'}{formatCurrency(transaction?.amount)}
                  </p>
                </div>
                <div className="flex items-center justify-between mt-1">
                  <p className="text-xs text-muted-foreground">
                    {transaction?.category}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {formatDate(transaction?.date)}
                  </p>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
      {transactions?.length > 0 && (
        <div className="mt-4 pt-3 border-t border-border">
          <Link 
            to="/transaction-history"
            className="w-full flex items-center justify-center space-x-2 py-2 text-sm text-primary hover:text-primary/80 font-medium"
          >
            <span>Lihat Riwayat Lengkap</span>
            <Icon name="ArrowRight" size={16} />
          </Link>
        </div>
      )}
    </div>
  );
};

export default RecentTransactions;