import React from 'react';
import Icon from '../../../components/AppIcon';

const SummaryCard = ({ title, amount, type, icon, trend }) => {
  const formatCurrency = (value) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    })?.format(value);
  };

  const getCardStyles = () => {
    switch (type) {
      case 'income':
        return 'bg-emerald-50 border-emerald-200 text-emerald-800';
      case 'expense':
        return 'bg-red-50 border-red-200 text-red-800';
      case 'balance':
        return amount >= 0 
          ? 'bg-blue-50 border-blue-200 text-blue-800' :'bg-red-50 border-red-200 text-red-800';
      default:
        return 'bg-card border-border text-card-foreground';
    }
  };

  const getIconColor = () => {
    switch (type) {
      case 'income':
        return '#059669';
      case 'expense':
        return '#DC2626';
      case 'balance':
        return amount >= 0 ? '#2563EB' : '#DC2626';
      default:
        return 'currentColor';
    }
  };

  return (
    <div className={`p-4 rounded-lg border-2 transition-all duration-200 hover:shadow-md ${getCardStyles()}`}>
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center space-x-2">
          <div className="p-2 rounded-full bg-white/50">
            <Icon name={icon} size={20} color={getIconColor()} />
          </div>
          <h3 className="text-sm font-medium opacity-80">{title}</h3>
        </div>
        {trend && (
          <div className={`flex items-center space-x-1 text-xs ${
            trend?.direction === 'up' ? 'text-emerald-600' : 'text-red-600'
          }`}>
            <Icon 
              name={trend?.direction === 'up' ? 'TrendingUp' : 'TrendingDown'} 
              size={12} 
            />
            <span>{trend?.percentage}%</span>
          </div>
        )}
      </div>
      <div className="space-y-1">
        <p className="text-2xl font-bold">{formatCurrency(amount)}</p>
        {trend && (
          <p className="text-xs opacity-60">
            {trend?.direction === 'up' ? 'Naik' : 'Turun'} dari bulan lalu
          </p>
        )}
      </div>
    </div>
  );
};

export default SummaryCard;