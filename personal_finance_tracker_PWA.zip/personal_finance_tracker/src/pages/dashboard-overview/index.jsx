import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Header from '../../components/ui/Header';
import MobileNavigation from '../../components/ui/MobileNavigation';
import FloatingActionButton from '../../components/ui/FloatingActionButton';
import SummaryCard from './components/SummaryCard';
import FinancialChart from './components/FinancialChart';
import RecentTransactions from './components/RecentTransactions';
import PeriodFilter from './components/PeriodFilter';
import QuickActions from './components/QuickActions';
import Button from '../../components/ui/Button';
import Icon from '../../components/AppIcon';

const DashboardOverview = () => {
  const [selectedPeriod, setSelectedPeriod] = useState('current-month');
  const [chartType, setChartType] = useState('bar');
  const [currentLanguage, setCurrentLanguage] = useState('id');

  // Mock transaction data
  const mockTransactions = [
    {
      id: 1,
      type: 'pemasukan',
      category: 'Gaji',
      amount: 8500000,
      description: 'Gaji bulan Agustus',
      date: '2025-08-01',
      notes: 'Gaji pokok + tunjangan'
    },
    {
      id: 2,
      type: 'pengeluaran',
      category: 'Makanan',
      amount: 150000,
      description: 'Makan siang di restoran',
      date: '2025-08-01',
      notes: 'Makan dengan keluarga'
    },
    {
      id: 3,
      type: 'pengeluaran',
      category: 'Transportasi',
      amount: 50000,
      description: 'Bensin motor',
      date: '2025-08-01',
      notes: 'Isi bensin Pertamax'
    },
    {
      id: 4,
      type: 'pemasukan',
      category: 'Freelance',
      amount: 2000000,
      description: 'Project website',
      date: '2025-07-31',
      notes: 'Pembayaran project selesai'
    },
    {
      id: 5,
      type: 'pengeluaran',
      category: 'Belanja',
      amount: 300000,
      description: 'Belanja bulanan',
      date: '2025-07-30',
      notes: 'Belanja kebutuhan rumah'
    },
    {
      id: 6,
      type: 'pengeluaran',
      category: 'Hiburan',
      amount: 100000,
      description: 'Nonton bioskop',
      date: '2025-07-29',
      notes: 'Film terbaru dengan teman'
    },
    {
      id: 7,
      type: 'pemasukan',
      category: 'Bonus',
      amount: 1500000,
      description: 'Bonus kinerja',
      date: '2025-07-28',
      notes: 'Bonus triwulan kedua'
    }
  ];

  // Mock chart data
  const mockChartData = [
    { name: 'Jan', pemasukan: 8500000, pengeluaran: 6200000 },
    { name: 'Feb', pemasukan: 9200000, pengeluaran: 5800000 },
    { name: 'Mar', pemasukan: 8800000, pengeluaran: 6500000 },
    { name: 'Apr', pemasukan: 9500000, pengeluaran: 7100000 },
    { name: 'Mei', pemasukan: 8700000, pengeluaran: 6300000 },
    { name: 'Jun', pemasukan: 9100000, pengeluaran: 6800000 },
    { name: 'Jul', pemasukan: 10200000, pengeluaran: 7200000 },
    { name: 'Agu', pemasukan: 8500000, pengeluaran: 5900000 }
  ];

  // Check localStorage for saved language preference
  useEffect(() => {
    const savedLanguage = localStorage.getItem('selectedLanguage');
    if (savedLanguage) {
      setCurrentLanguage(savedLanguage);
    }
  }, []);

  // Calculate financial summary
  const calculateSummary = () => {
    const totalIncome = mockTransactions?.filter(t => t?.type === 'pemasukan')?.reduce((sum, t) => sum + t?.amount, 0);
    
    const totalExpense = mockTransactions?.filter(t => t?.type === 'pengeluaran')?.reduce((sum, t) => sum + t?.amount, 0);
    
    const balance = totalIncome - totalExpense;

    return {
      totalIncome,
      totalExpense,
      balance
    };
  };

  const { totalIncome, totalExpense, balance } = calculateSummary();

  // Get recent transactions (latest 5)
  const recentTransactions = mockTransactions?.sort((a, b) => new Date(b.date) - new Date(a.date))?.slice(0, 5);

  const getPeriodLabel = () => {
    switch (selectedPeriod) {
      case 'current-month':
        return 'Agustus 2025';
      case 'last-month':
        return 'Juli 2025';
      case 'current-year':
        return 'Tahun 2025';
      case 'last-year':
        return 'Tahun 2024';
      case 'all-time':
        return 'Semua Waktu';
      default:
        return 'Agustus 2025';
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto px-4 py-6 pb-20 md:pb-6">
        {/* Welcome Section */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-foreground mb-2">
            Dashboard Keuangan
          </h1>
          <p className="text-muted-foreground">
            Pantau kondisi keuangan Anda dengan mudah
          </p>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <SummaryCard
            title="Total Pemasukan"
            amount={totalIncome}
            type="income"
            icon="TrendingUp"
            trend={{ direction: 'up', percentage: 12 }}
          />
          <SummaryCard
            title="Total Pengeluaran"
            amount={totalExpense}
            type="expense"
            icon="TrendingDown"
            trend={{ direction: 'down', percentage: 8 }}
          />
          <SummaryCard
            title="Saldo"
            amount={balance}
            type="balance"
            icon="Wallet"
          />
        </div>

        {/* Quick Actions - Mobile Only */}
        <div className="md:hidden mb-6">
          <QuickActions />
        </div>

        {/* Chart Section */}
        <div className="mb-6">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-4">
            <PeriodFilter
              selectedPeriod={selectedPeriod}
              onPeriodChange={setSelectedPeriod}
            />
            <div className="flex items-center space-x-2 mt-3 sm:mt-0">
              <Button
                variant={chartType === 'bar' ? 'default' : 'outline'}
                size="sm"
                iconName="BarChart3"
                onClick={() => setChartType('bar')}
              >
                Bar
              </Button>
              <Button
                variant={chartType === 'pie' ? 'default' : 'outline'}
                size="sm"
                iconName="PieChart"
                onClick={() => setChartType('pie')}
              >
                Pie
              </Button>
            </div>
          </div>
          
          <FinancialChart
            data={mockChartData}
            chartType={chartType}
            period={getPeriodLabel()}
          />
        </div>

        {/* Recent Transactions */}
        <div className="mb-6">
          <RecentTransactions transactions={recentTransactions} />
        </div>

        {/* Quick Actions - Desktop Only */}
        <div className="hidden md:block">
          <QuickActions />
        </div>

        {/* Empty State for No Data */}
        {mockTransactions?.length === 0 && (
          <div className="text-center py-12">
            <div className="w-24 h-24 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
              <Icon name="PiggyBank" size={32} color="#64748B" />
            </div>
            <h3 className="text-lg font-semibold text-foreground mb-2">
              Mulai Kelola Keuangan Anda
            </h3>
            <p className="text-muted-foreground mb-6 max-w-md mx-auto">
              Belum ada data transaksi. Tambahkan transaksi pertama Anda untuk mulai melacak keuangan.
            </p>
            <Link to="/add-transaction">
              <Button iconName="Plus" iconPosition="left">
                Tambah Transaksi Pertama
              </Button>
            </Link>
          </div>
        )}
      </main>
      <MobileNavigation />
      <FloatingActionButton />
    </div>
  );
};

export default DashboardOverview;