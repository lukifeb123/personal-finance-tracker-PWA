import React from 'react';
import Input from '../../../components/ui/Input';
import Icon from '../../../components/AppIcon';

const SearchBar = ({ searchQuery, setSearchQuery }) => {
  return (
    <div className="relative mb-6">
      <div className="absolute inset-y-0 left-3 flex items-center pointer-events-none">
        <Icon name="Search" size={16} className="text-muted-foreground" />
      </div>
      <Input
        type="search"
        placeholder="Cari transaksi berdasarkan deskripsi atau jumlah..."
        value={searchQuery}
        onChange={(e) => setSearchQuery(e?.target?.value)}
        className="pl-10"
      />
    </div>
  );
};

export default SearchBar;