import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const TransactionCard = ({ transaction, onEdit, onDelete }) => {
  const getCategoryIcon = (category) => {
    const iconMap = {
      'makanan': 'UtensilsCrossed',
      'transportasi': 'Car',
      'belanja': 'ShoppingBag',
      'hiburan': 'Gamepad2',
      'kesehatan': 'Heart',
      'pendidikan': 'GraduationCap',
      'tagihan': 'Receipt',
      'gaji': 'Banknote',
      'bonus': 'Gift',
      'investasi': 'TrendingUp',
      'lainnya': 'MoreHorizontal'
    };
    return iconMap?.[category] || 'MoreHorizontal';
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    })?.format(amount);
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date?.toLocaleDateString('id-ID', {
      day: '2-digit',
      month: 'short',
      year: 'numeric'
    });
  };

  const isIncome = transaction?.type === 'income';

  return (
    <div className="bg-card border border-border rounded-lg p-4 hover:shadow-md transition-shadow duration-200">
      <div className="flex items-start justify-between">
        <div className="flex items-start space-x-3 flex-1">
          <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
            isIncome ? 'bg-success/10' : 'bg-error/10'
          }`}>
            <Icon 
              name={getCategoryIcon(transaction?.category)} 
              size={20} 
              className={isIncome ? 'text-success' : 'text-error'} 
            />
          </div>
          
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between mb-1">
              <h4 className="text-sm font-medium text-foreground truncate">
                {transaction?.description}
              </h4>
              <span className={`text-sm font-semibold ${
                isIncome ? 'text-success' : 'text-error'
              }`}>
                {isIncome ? '+' : '-'}{formatCurrency(Math.abs(transaction?.amount))}
              </span>
            </div>
            
            <div className="flex items-center justify-between text-xs text-muted-foreground">
              <span className="capitalize">{transaction?.category?.replace('-', ' ')}</span>
              <span>{formatDate(transaction?.date)}</span>
            </div>
            
            {transaction?.notes && (
              <p className="text-xs text-muted-foreground mt-2 line-clamp-2">
                {transaction?.notes}
              </p>
            )}
          </div>
        </div>
      </div>
      <div className="flex items-center justify-end space-x-2 mt-3 pt-3 border-t border-border">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => onEdit(transaction)}
          iconName="Edit"
          iconPosition="left"
        >
          Edit
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => onDelete(transaction?.id)}
          iconName="Trash2"
          iconPosition="left"
          className="text-error hover:text-error"
        >
          Hapus
        </Button>
      </div>
    </div>
  );
};

export default TransactionCard;