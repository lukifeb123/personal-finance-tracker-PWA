import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import { Link } from 'react-router-dom';

const EmptyState = ({ hasFilters, onClearFilters }) => {
  if (hasFilters) {
    return (
      <div className="text-center py-12">
        <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
          <Icon name="Search" size={24} className="text-muted-foreground" />
        </div>
        <h3 className="text-lg font-semibold text-foreground mb-2">
          Tidak Ada Transaksi Ditemukan
        </h3>
        <p className="text-muted-foreground mb-6 max-w-md mx-auto">
          Tidak ada transaksi yang sesuai dengan filter yang dipilih. Coba ubah kriteria pencarian Anda.
        </p>
        <Button variant="outline" onClick={onClearFilters}>
          Hapus Semua Filter
        </Button>
      </div>
    );
  }

  return (
    <div className="text-center py-12">
      <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
        <Icon name="Receipt" size={24} className="text-muted-foreground" />
      </div>
      <h3 className="text-lg font-semibold text-foreground mb-2">
        Belum Ada Transaksi
      </h3>
      <p className="text-muted-foreground mb-6 max-w-md mx-auto">
        Anda belum memiliki transaksi apapun. Mulai catat transaksi pertama Anda untuk melacak keuangan.
      </p>
      <Link to="/add-transaction">
        <Button iconName="Plus" iconPosition="left">
          Tambah Transaksi Pertama
        </Button>
      </Link>
    </div>
  );
};

export default EmptyState;