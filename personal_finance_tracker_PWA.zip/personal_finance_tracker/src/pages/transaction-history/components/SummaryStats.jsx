import React from 'react';
import Icon from '../../../components/AppIcon';

const SummaryStats = ({ transactions, filteredTransactions }) => {
  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    })?.format(amount);
  };

  const calculateStats = (transactions) => {
    const income = transactions?.filter(t => t?.type === 'income')?.reduce((sum, t) => sum + t?.amount, 0);
    
    const expense = transactions?.filter(t => t?.type === 'expense')?.reduce((sum, t) => sum + Math.abs(t?.amount), 0);
    
    return {
      income,
      expense,
      balance: income - expense,
      count: transactions?.length
    };
  };

  const stats = calculateStats(filteredTransactions);

  return (
    <div className="sticky bottom-0 md:bottom-auto bg-card border-t md:border border-border p-4 md:rounded-lg mb-20 md:mb-0">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-sm font-semibold text-foreground">Ringkasan Transaksi</h3>
        <span className="text-xs text-muted-foreground">
          {stats?.count} dari {transactions?.length} transaksi
        </span>
      </div>
      <div className="grid grid-cols-3 gap-4">
        <div className="text-center">
          <div className="flex items-center justify-center w-8 h-8 bg-success/10 rounded-full mx-auto mb-2">
            <Icon name="TrendingUp" size={16} className="text-success" />
          </div>
          <p className="text-xs text-muted-foreground mb-1">Pemasukan</p>
          <p className="text-sm font-semibold text-success">
            {formatCurrency(stats?.income)}
          </p>
        </div>
        
        <div className="text-center">
          <div className="flex items-center justify-center w-8 h-8 bg-error/10 rounded-full mx-auto mb-2">
            <Icon name="TrendingDown" size={16} className="text-error" />
          </div>
          <p className="text-xs text-muted-foreground mb-1">Pengeluaran</p>
          <p className="text-sm font-semibold text-error">
            {formatCurrency(stats?.expense)}
          </p>
        </div>
        
        <div className="text-center">
          <div className={`flex items-center justify-center w-8 h-8 rounded-full mx-auto mb-2 ${
            stats?.balance >= 0 ? 'bg-success/10' : 'bg-error/10'
          }`}>
            <Icon 
              name="Wallet" 
              size={16} 
              className={stats?.balance >= 0 ? 'text-success' : 'text-error'} 
            />
          </div>
          <p className="text-xs text-muted-foreground mb-1">Saldo</p>
          <p className={`text-sm font-semibold ${
            stats?.balance >= 0 ? 'text-success' : 'text-error'
          }`}>
            {formatCurrency(stats?.balance)}
          </p>
        </div>
      </div>
    </div>
  );
};

export default SummaryStats;