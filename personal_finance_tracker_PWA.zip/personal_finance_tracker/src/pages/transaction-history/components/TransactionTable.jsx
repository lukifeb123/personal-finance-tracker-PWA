import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const TransactionTable = ({ transactions, onEdit, onDelete, onSort, sortField, sortDirection }) => {
  const getCategoryIcon = (category) => {
    const iconMap = {
      'makanan': 'UtensilsCrossed',
      'transportasi': 'Car',
      'belanja': 'ShoppingBag',
      'hiburan': 'Gamepad2',
      'kesehatan': 'Heart',
      'pendidikan': 'GraduationCap',
      'tagihan': 'Receipt',
      'gaji': 'Banknote',
      'bonus': 'Gift',
      'investasi': 'TrendingUp',
      'lainnya': 'MoreHorizontal'
    };
    return iconMap?.[category] || 'MoreHorizontal';
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    })?.format(amount);
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date?.toLocaleDateString('id-ID', {
      day: '2-digit',
      month: 'short',
      year: 'numeric'
    });
  };

  const handleSort = (field) => {
    onSort(field);
  };

  const getSortIcon = (field) => {
    if (sortField !== field) return 'ArrowUpDown';
    return sortDirection === 'asc' ? 'ArrowUp' : 'ArrowDown';
  };

  return (
    <div className="bg-card border border-border rounded-lg overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-muted/50">
            <tr>
              <th className="px-4 py-3 text-left">
                <button
                  onClick={() => handleSort('date')}
                  className="flex items-center space-x-1 text-sm font-medium text-foreground hover:text-primary"
                >
                  <span>Tanggal</span>
                  <Icon name={getSortIcon('date')} size={14} />
                </button>
              </th>
              <th className="px-4 py-3 text-left">
                <button
                  onClick={() => handleSort('type')}
                  className="flex items-center space-x-1 text-sm font-medium text-foreground hover:text-primary"
                >
                  <span>Tipe</span>
                  <Icon name={getSortIcon('type')} size={14} />
                </button>
              </th>
              <th className="px-4 py-3 text-left">
                <button
                  onClick={() => handleSort('category')}
                  className="flex items-center space-x-1 text-sm font-medium text-foreground hover:text-primary"
                >
                  <span>Kategori</span>
                  <Icon name={getSortIcon('category')} size={14} />
                </button>
              </th>
              <th className="px-4 py-3 text-left">
                <button
                  onClick={() => handleSort('description')}
                  className="flex items-center space-x-1 text-sm font-medium text-foreground hover:text-primary"
                >
                  <span>Deskripsi</span>
                  <Icon name={getSortIcon('description')} size={14} />
                </button>
              </th>
              <th className="px-4 py-3 text-right">
                <button
                  onClick={() => handleSort('amount')}
                  className="flex items-center space-x-1 text-sm font-medium text-foreground hover:text-primary ml-auto"
                >
                  <span>Jumlah</span>
                  <Icon name={getSortIcon('amount')} size={14} />
                </button>
              </th>
              <th className="px-4 py-3 text-center">
                <span className="text-sm font-medium text-foreground">Aksi</span>
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {transactions?.map((transaction) => {
              const isIncome = transaction?.type === 'income';
              return (
                <tr key={transaction?.id} className="hover:bg-muted/30 transition-colors">
                  <td className="px-4 py-3 text-sm text-foreground">
                    {formatDate(transaction?.date)}
                  </td>
                  <td className="px-4 py-3">
                    <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                      isIncome 
                        ? 'bg-success/10 text-success' :'bg-error/10 text-error'
                    }`}>
                      <Icon 
                        name={isIncome ? 'TrendingUp' : 'TrendingDown'} 
                        size={12} 
                        className="mr-1" 
                      />
                      {isIncome ? 'Pemasukan' : 'Pengeluaran'}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center space-x-2">
                      <div className={`w-6 h-6 rounded-full flex items-center justify-center ${
                        isIncome ? 'bg-success/10' : 'bg-error/10'
                      }`}>
                        <Icon 
                          name={getCategoryIcon(transaction?.category)} 
                          size={12} 
                          className={isIncome ? 'text-success' : 'text-error'} 
                        />
                      </div>
                      <span className="text-sm text-foreground capitalize">
                        {transaction?.category?.replace('-', ' ')}
                      </span>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <div>
                      <p className="text-sm text-foreground font-medium">
                        {transaction?.description}
                      </p>
                      {transaction?.notes && (
                        <p className="text-xs text-muted-foreground mt-1 line-clamp-1">
                          {transaction?.notes}
                        </p>
                      )}
                    </div>
                  </td>
                  <td className="px-4 py-3 text-right">
                    <span className={`text-sm font-semibold ${
                      isIncome ? 'text-success' : 'text-error'
                    }`}>
                      {isIncome ? '+' : '-'}{formatCurrency(Math.abs(transaction?.amount))}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-center space-x-1">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => onEdit(transaction)}
                        iconName="Edit"
                        className="h-8 w-8 p-0"
                      />
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => onDelete(transaction?.id)}
                        iconName="Trash2"
                        className="h-8 w-8 p-0 text-error hover:text-error"
                      />
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default TransactionTable;