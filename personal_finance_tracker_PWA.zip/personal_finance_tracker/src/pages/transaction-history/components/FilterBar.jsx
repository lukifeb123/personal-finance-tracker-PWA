import React from 'react';
import Select from '../../../components/ui/Select';
import Button from '../../../components/ui/Button';


const FilterBar = ({ 
  selectedMonth, 
  setSelectedMonth, 
  selectedYear, 
  setSelectedYear, 
  selectedType, 
  setSelectedType, 
  selectedCategory, 
  setSelectedCategory,
  onClearFilters 
}) => {
  const monthOptions = [
    { value: '', label: 'Semua Bulan' },
    { value: '01', label: 'Januari' },
    { value: '02', label: 'Februari' },
    { value: '03', label: 'Maret' },
    { value: '04', label: 'April' },
    { value: '05', label: 'Mei' },
    { value: '06', label: 'Juni' },
    { value: '07', label: 'Juli' },
    { value: '08', label: 'Agustus' },
    { value: '09', label: 'September' },
    { value: '10', label: 'Oktober' },
    { value: '11', label: 'November' },
    { value: '12', label: 'Desember' }
  ];

  const yearOptions = [
    { value: '', label: 'Semua Tahun' },
    { value: '2024', label: '2024' },
    { value: '2023', label: '2023' },
    { value: '2022', label: '2022' }
  ];

  const typeOptions = [
    { value: '', label: 'Semua Tipe' },
    { value: 'income', label: 'Pemasukan' },
    { value: 'expense', label: 'Pengeluaran' }
  ];

  const categoryOptions = [
    { value: '', label: 'Semua Kategori' },
    { value: 'makanan', label: 'Makanan & Minuman' },
    { value: 'transportasi', label: 'Transportasi' },
    { value: 'belanja', label: 'Belanja' },
    { value: 'hiburan', label: 'Hiburan' },
    { value: 'kesehatan', label: 'Kesehatan' },
    { value: 'pendidikan', label: 'Pendidikan' },
    { value: 'tagihan', label: 'Tagihan' },
    { value: 'gaji', label: 'Gaji' },
    { value: 'bonus', label: 'Bonus' },
    { value: 'investasi', label: 'Investasi' },
    { value: 'lainnya', label: 'Lainnya' }
  ];

  return (
    <div className="bg-card border border-border rounded-lg p-4 mb-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-foreground">Filter Transaksi</h3>
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={onClearFilters}
          iconName="X"
          iconPosition="left"
        >
          Hapus Filter
        </Button>
      </div>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Select
          label="Bulan"
          options={monthOptions}
          value={selectedMonth}
          onChange={setSelectedMonth}
          placeholder="Pilih bulan"
        />
        
        <Select
          label="Tahun"
          options={yearOptions}
          value={selectedYear}
          onChange={setSelectedYear}
          placeholder="Pilih tahun"
        />
        
        <Select
          label="Tipe Transaksi"
          options={typeOptions}
          value={selectedType}
          onChange={setSelectedType}
          placeholder="Pilih tipe"
        />
        
        <Select
          label="Kategori"
          options={categoryOptions}
          value={selectedCategory}
          onChange={setSelectedCategory}
          placeholder="Pilih kategori"
          searchable
        />
      </div>
    </div>
  );
};

export default FilterBar;