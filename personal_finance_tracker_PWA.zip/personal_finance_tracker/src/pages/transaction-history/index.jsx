import React, { useState, useEffect, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import Header from '../../components/ui/Header';
import MobileNavigation from '../../components/ui/MobileNavigation';
import FloatingActionButton from '../../components/ui/FloatingActionButton';
import FilterBar from './components/FilterBar';
import SearchBar from './components/SearchBar';
import TransactionCard from './components/TransactionCard';
import TransactionTable from './components/TransactionTable';
import SummaryStats from './components/SummaryStats';
import EmptyState from './components/EmptyState';
import Icon from '../../components/AppIcon';

const TransactionHistory = () => {
  // Mock transaction data
  const mockTransactions = [
    {
      id: 1,
      date: '2024-08-01',
      type: 'expense',
      category: 'makanan',
      description: 'Makan siang di restoran',
      amount: -75000,
      notes: 'Makan bersama teman kantor'
    },
    {
      id: 2,
      date: '2024-08-01',
      type: 'income',
      category: 'gaji',
      description: 'Gaji bulanan',
      amount: 8500000,
      notes: 'Gaji bulan Agustus 2024'
    },
    {
      id: 3,
      date: '2024-07-31',
      type: 'expense',
      category: 'transportasi',
      description: 'Bensin motor',
      amount: -50000,
      notes: 'Isi bensin untuk perjalanan kerja'
    },
    {
      id: 4,
      date: '2024-07-30',
      type: 'expense',
      category: 'belanja',
      description: 'Belanja bulanan',
      amount: -450000,
      notes: 'Belanja kebutuhan rumah tangga di supermarket'
    },
    {
      id: 5,
      date: '2024-07-29',
      type: 'income',
      category: 'bonus',
      description: 'Bonus proyek',
      amount: 1500000,
      notes: 'Bonus penyelesaian proyek aplikasi mobile'
    },
    {
      id: 6,
      date: '2024-07-28',
      type: 'expense',
      category: 'hiburan',
      description: 'Nonton bioskop',
      amount: -85000,
      notes: 'Nonton film bersama keluarga'
    },
    {
      id: 7,
      date: '2024-07-27',
      type: 'expense',
      category: 'kesehatan',
      description: 'Konsultasi dokter',
      amount: -200000,
      notes: 'Pemeriksaan kesehatan rutin'
    },
    {
      id: 8,
      date: '2024-07-26',
      type: 'expense',
      category: 'tagihan',
      description: 'Tagihan listrik',
      amount: -350000,
      notes: 'Tagihan listrik bulan Juli 2024'
    },
    {
      id: 9,
      date: '2024-07-25',
      type: 'income',
      category: 'investasi',
      description: 'Dividen saham',
      amount: 250000,
      notes: 'Dividen dari investasi saham BBCA'
    },
    {
      id: 10,
      date: '2024-07-24',
      type: 'expense',
      category: 'pendidikan',
      description: 'Kursus online',
      amount: -299000,
      notes: 'Kursus React.js di platform online'
    }
  ];

  // State management
  const [transactions, setTransactions] = useState(mockTransactions);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedMonth, setSelectedMonth] = useState('');
  const [selectedYear, setSelectedYear] = useState('');
  const [selectedType, setSelectedType] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [sortField, setSortField] = useState('date');
  const [sortDirection, setSortDirection] = useState('desc');
  const [viewMode, setViewMode] = useState('card'); // 'card' or 'table'

  // Load data from localStorage on component mount
  useEffect(() => {
    const savedTransactions = localStorage.getItem('financeTracker_transactions');
    if (savedTransactions) {
      try {
        const parsedTransactions = JSON.parse(savedTransactions);
        setTransactions([...mockTransactions, ...parsedTransactions]);
      } catch (error) {
        console.error('Error parsing saved transactions:', error);
      }
    }
  }, []);

  // Filter and search logic
  const filteredTransactions = useMemo(() => {
    let filtered = transactions;

    // Search filter
    if (searchQuery) {
      filtered = filtered?.filter(transaction =>
        transaction?.description?.toLowerCase()?.includes(searchQuery?.toLowerCase()) ||
        Math.abs(transaction?.amount)?.toString()?.includes(searchQuery?.replace(/\D/g, ''))
      );
    }

    // Month filter
    if (selectedMonth) {
      filtered = filtered?.filter(transaction => {
        const transactionMonth = new Date(transaction.date)?.getMonth() + 1;
        return transactionMonth?.toString()?.padStart(2, '0') === selectedMonth;
      });
    }

    // Year filter
    if (selectedYear) {
      filtered = filtered?.filter(transaction => {
        const transactionYear = new Date(transaction.date)?.getFullYear();
        return transactionYear?.toString() === selectedYear;
      });
    }

    // Type filter
    if (selectedType) {
      filtered = filtered?.filter(transaction => transaction?.type === selectedType);
    }

    // Category filter
    if (selectedCategory) {
      filtered = filtered?.filter(transaction => transaction?.category === selectedCategory);
    }

    // Sort
    filtered?.sort((a, b) => {
      let aValue = a?.[sortField];
      let bValue = b?.[sortField];

      if (sortField === 'date') {
        aValue = new Date(aValue);
        bValue = new Date(bValue);
      } else if (sortField === 'amount') {
        aValue = Math.abs(aValue);
        bValue = Math.abs(bValue);
      }

      if (sortDirection === 'asc') {
        return aValue > bValue ? 1 : -1;
      } else {
        return aValue < bValue ? 1 : -1;
      }
    });

    return filtered;
  }, [transactions, searchQuery, selectedMonth, selectedYear, selectedType, selectedCategory, sortField, sortDirection]);

  // Handler functions
  const handleClearFilters = () => {
    setSearchQuery('');
    setSelectedMonth('');
    setSelectedYear('');
    setSelectedType('');
    setSelectedCategory('');
  };

  const handleSort = (field) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('desc');
    }
  };

  const handleEdit = (transaction) => {
    // In a real app, this would navigate to edit form or open modal
    console.log('Edit transaction:', transaction);
    alert(`Edit transaksi: ${transaction?.description}`);
  };

  const handleDelete = (transactionId) => {
    if (window.confirm('Apakah Anda yakin ingin menghapus transaksi ini?')) {
      const updatedTransactions = transactions?.filter(t => t?.id !== transactionId);
      setTransactions(updatedTransactions);
      
      // Update localStorage
      const customTransactions = updatedTransactions?.filter(t => t?.id > 10);
      localStorage.setItem('financeTracker_transactions', JSON.stringify(customTransactions));
    }
  };

  const hasActiveFilters = searchQuery || selectedMonth || selectedYear || selectedType || selectedCategory;

  return (
    <>
      <Helmet>
        <title>Riwayat Transaksi - FinanceTracker</title>
        <meta name="description" content="Lihat dan kelola semua transaksi keuangan Anda dengan filter dan pencarian yang mudah" />
      </Helmet>
      <div className="min-h-screen bg-background">
        <Header />
        
        <main className="container mx-auto px-4 py-6 pb-24 md:pb-6">
          {/* Page Header */}
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-2xl font-bold text-foreground">Riwayat Transaksi</h1>
              <p className="text-muted-foreground mt-1">
                Kelola dan analisis semua transaksi keuangan Anda
              </p>
            </div>
            
            {/* View Mode Toggle - Desktop Only */}
            <div className="hidden md:flex items-center space-x-2 bg-muted rounded-lg p-1">
              <button
                onClick={() => setViewMode('card')}
                className={`flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  viewMode === 'card' ?'bg-background text-foreground shadow-sm' :'text-muted-foreground hover:text-foreground'
                }`}
              >
                <Icon name="LayoutGrid" size={16} />
                <span>Kartu</span>
              </button>
              <button
                onClick={() => setViewMode('table')}
                className={`flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  viewMode === 'table' ?'bg-background text-foreground shadow-sm' :'text-muted-foreground hover:text-foreground'
                }`}
              >
                <Icon name="Table" size={16} />
                <span>Tabel</span>
              </button>
            </div>
          </div>

          {/* Search Bar */}
          <SearchBar 
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
          />

          {/* Filter Bar */}
          <FilterBar
            selectedMonth={selectedMonth}
            setSelectedMonth={setSelectedMonth}
            selectedYear={selectedYear}
            setSelectedYear={setSelectedYear}
            selectedType={selectedType}
            setSelectedType={setSelectedType}
            selectedCategory={selectedCategory}
            setSelectedCategory={setSelectedCategory}
            onClearFilters={handleClearFilters}
          />

          {/* Content */}
          {filteredTransactions?.length === 0 ? (
            <EmptyState 
              hasFilters={hasActiveFilters}
              onClearFilters={handleClearFilters}
            />
          ) : (
            <>
              {/* Mobile Card View */}
              <div className="md:hidden space-y-4 mb-6">
                {filteredTransactions?.map((transaction) => (
                  <TransactionCard
                    key={transaction?.id}
                    transaction={transaction}
                    onEdit={handleEdit}
                    onDelete={handleDelete}
                  />
                ))}
              </div>

              {/* Desktop View */}
              <div className="hidden md:block mb-6">
                {viewMode === 'card' ? (
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                    {filteredTransactions?.map((transaction) => (
                      <TransactionCard
                        key={transaction?.id}
                        transaction={transaction}
                        onEdit={handleEdit}
                        onDelete={handleDelete}
                      />
                    ))}
                  </div>
                ) : (
                  <TransactionTable
                    transactions={filteredTransactions}
                    onEdit={handleEdit}
                    onDelete={handleDelete}
                    onSort={handleSort}
                    sortField={sortField}
                    sortDirection={sortDirection}
                  />
                )}
              </div>
            </>
          )}

          {/* Summary Stats */}
          {filteredTransactions?.length > 0 && (
            <SummaryStats
              transactions={transactions}
              filteredTransactions={filteredTransactions}
            />
          )}
        </main>

        <MobileNavigation />
        <FloatingActionButton />
      </div>
    </>
  );
};

export default TransactionHistory;