import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../../components/ui/Header';
import MobileNavigation from '../../components/ui/MobileNavigation';
import FloatingActionButton from '../../components/ui/FloatingActionButton';
import TransactionTypeToggle from './components/TransactionTypeToggle';
import CategorySelect from './components/CategorySelect';
import AmountInput from './components/AmountInput';
import DateInput from './components/DateInput';
import NotesInput from './components/NotesInput';
import FormActions from './components/FormActions';
import SuccessModal from './components/SuccessModal';
import Icon from '../../components/AppIcon';

const AddTransaction = () => {
  const navigate = useNavigate();
  
  // Form state
  const [formData, setFormData] = useState({
    date: new Date()?.toISOString()?.split('T')?.[0],
    type: '',
    category: '',
    amount: '',
    notes: ''
  });

  // UI state
  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [showSuccessModal, setShowSuccessModal] = useState(false);

  // Load saved draft from localStorage on component mount
  useEffect(() => {
    const savedDraft = localStorage.getItem('transactionDraft');
    if (savedDraft) {
      try {
        const draft = JSON.parse(savedDraft);
        setFormData(prev => ({ ...prev, ...draft }));
      } catch (error) {
        console.error('Error loading draft:', error);
      }
    }
  }, []);

  // Save draft to localStorage whenever form data changes
  useEffect(() => {
    const timeoutId = setTimeout(() => {
      localStorage.setItem('transactionDraft', JSON.stringify(formData));
    }, 500);

    return () => clearTimeout(timeoutId);
  }, [formData]);

  // Form handlers
  const handleTypeChange = (type) => {
    setFormData(prev => ({ ...prev, type, category: '' }));
    setErrors(prev => ({ ...prev, type: '', category: '' }));
  };

  const handleCategoryChange = (category) => {
    setFormData(prev => ({ ...prev, category }));
    setErrors(prev => ({ ...prev, category: '' }));
  };

  const handleAmountChange = (amount) => {
    setFormData(prev => ({ ...prev, amount }));
    setErrors(prev => ({ ...prev, amount: '' }));
  };

  const handleDateChange = (date) => {
    setFormData(prev => ({ ...prev, date }));
    setErrors(prev => ({ ...prev, date: '' }));
  };

  const handleNotesChange = (notes) => {
    if (notes?.length <= 200) {
      setFormData(prev => ({ ...prev, notes }));
    }
  };

  // Validation
  const validateForm = () => {
    const newErrors = {};

    if (!formData?.date) {
      newErrors.date = 'Tanggal harus diisi';
    }

    if (!formData?.type) {
      newErrors.type = 'Jenis transaksi harus dipilih';
    }

    if (!formData?.category) {
      newErrors.category = 'Kategori harus dipilih';
    }

    if (!formData?.amount || formData?.amount === '0') {
      newErrors.amount = 'Jumlah harus diisi dan lebih dari 0';
    }

    setErrors(newErrors);
    return Object.keys(newErrors)?.length === 0;
  };

  // Convert formatted amount to number
  const parseAmount = (formattedAmount) => {
    return parseFloat(formattedAmount?.replace(/\./g, '')?.replace(',', '.')) || 0;
  };

  // Save transaction
  const handleSave = async () => {
    if (!validateForm()) return;

    setIsLoading(true);

    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));

      // Get existing transactions
      const existingTransactions = JSON.parse(localStorage.getItem('transactions') || '[]');
      
      // Create new transaction
      const newTransaction = {
        id: Date.now()?.toString(),
        date: formData?.date,
        type: formData?.type,
        category: formData?.category,
        amount: parseAmount(formData?.amount),
        notes: formData?.notes,
        createdAt: new Date()?.toISOString()
      };

      // Save to localStorage
      const updatedTransactions = [newTransaction, ...existingTransactions];
      localStorage.setItem('transactions', JSON.stringify(updatedTransactions));

      // Clear draft
      localStorage.removeItem('transactionDraft');

      // Show success modal
      setShowSuccessModal(true);
      
    } catch (error) {
      console.error('Error saving transaction:', error);
      setErrors({ submit: 'Gagal menyimpan transaksi. Silakan coba lagi.' });
    } finally {
      setIsLoading(false);
    }
  };

  // Reset form
  const resetForm = () => {
    setFormData({
      date: new Date()?.toISOString()?.split('T')?.[0],
      type: '',
      category: '',
      amount: '',
      notes: ''
    });
    setErrors({});
    localStorage.removeItem('transactionDraft');
  };

  // Handle cancel
  const handleCancel = () => {
    if (Object.values(formData)?.some(value => value && value !== new Date()?.toISOString()?.split('T')?.[0])) {
      if (window.confirm('Apakah Anda yakin ingin membatalkan? Data yang belum disimpan akan hilang.')) {
        resetForm();
        navigate('/dashboard-overview');
      }
    } else {
      navigate('/dashboard-overview');
    }
  };

  // Success modal handlers
  const handleAddAnother = () => {
    setShowSuccessModal(false);
    resetForm();
  };

  const handleViewDashboard = () => {
    setShowSuccessModal(false);
    resetForm();
    navigate('/dashboard-overview');
  };

  // Check if form is valid
  const isFormValid = formData?.date && formData?.type && formData?.category && formData?.amount && formData?.amount !== '0';

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto px-4 py-6 pb-24 md:pb-6 max-w-2xl">
        {/* Page Header */}
        <div className="flex items-center space-x-3 mb-6">
          <button
            onClick={() => navigate('/dashboard-overview')}
            className="p-2 rounded-lg hover:bg-muted transition-colors"
          >
            <Icon name="ArrowLeft" size={20} />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-foreground">Tambah Transaksi</h1>
            <p className="text-sm text-muted-foreground">Catat transaksi keuangan Anda</p>
          </div>
        </div>

        {/* Form */}
        <div className="bg-card rounded-lg border border-border p-6 space-y-6">
          {/* Date Input */}
          <DateInput
            date={formData?.date}
            onDateChange={handleDateChange}
            error={errors?.date}
          />

          {/* Transaction Type Toggle */}
          <TransactionTypeToggle
            selectedType={formData?.type}
            onTypeChange={handleTypeChange}
          />
          {errors?.type && (
            <p className="text-sm text-error mt-1">{errors?.type}</p>
          )}

          {/* Category Select */}
          {formData?.type && (
            <CategorySelect
              selectedType={formData?.type}
              selectedCategory={formData?.category}
              onCategoryChange={handleCategoryChange}
              error={errors?.category}
            />
          )}

          {/* Amount Input */}
          <AmountInput
            amount={formData?.amount}
            onAmountChange={handleAmountChange}
            error={errors?.amount}
          />

          {/* Notes Input */}
          <NotesInput
            notes={formData?.notes}
            onNotesChange={handleNotesChange}
          />

          {/* Submit Error */}
          {errors?.submit && (
            <div className="p-3 bg-error/10 border border-error/20 rounded-md">
              <p className="text-sm text-error">{errors?.submit}</p>
            </div>
          )}

          {/* Form Actions */}
          <FormActions
            onSave={handleSave}
            onCancel={handleCancel}
            isLoading={isLoading}
            isValid={isFormValid}
          />
        </div>

        {/* Draft Indicator */}
        {Object.values(formData)?.some(value => value && value !== new Date()?.toISOString()?.split('T')?.[0]) && (
          <div className="mt-4 p-3 bg-accent/10 border border-accent/20 rounded-md">
            <div className="flex items-center space-x-2">
              <Icon name="Save" size={16} color="var(--color-accent)" />
              <p className="text-sm text-accent">Draft otomatis tersimpan</p>
            </div>
          </div>
        )}
      </main>
      {/* Success Modal */}
      <SuccessModal
        isOpen={showSuccessModal}
        onClose={() => setShowSuccessModal(false)}
        onAddAnother={handleAddAnother}
        onViewDashboard={handleViewDashboard}
      />
      <MobileNavigation />
      <FloatingActionButton />
    </div>
  );
};

export default AddTransaction;