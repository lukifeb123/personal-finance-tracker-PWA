import React from 'react';
import Input from '../../../components/ui/Input';

const AmountInput = ({ amount, onAmountChange, error }) => {
  const formatCurrency = (value) => {
    // Remove non-numeric characters except decimal point
    const numericValue = value?.replace(/[^\d,]/g, '');
    
    // Format with thousand separators
    const parts = numericValue?.split(',');
    parts[0] = parts?.[0]?.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
    
    return parts?.join(',');
  };

  const handleChange = (e) => {
    const inputValue = e?.target?.value;
    const formattedValue = formatCurrency(inputValue);
    onAmountChange(formattedValue);
  };

  return (
    <div className="space-y-2">
      <label className="block text-sm font-medium text-foreground">
        Jumlah <span className="text-error">*</span>
      </label>
      <div className="relative">
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          <span className="text-muted-foreground text-sm font-medium">Rp</span>
        </div>
        <Input
          type="text"
          placeholder="0"
          value={amount}
          onChange={handleChange}
          error={error}
          className="pl-12"
          inputMode="numeric"
        />
      </div>
      <p className="text-xs text-muted-foreground">
        Gunakan koma (,) untuk desimal dan titik (.) akan otomatis ditambahkan
      </p>
    </div>
  );
};

export default AmountInput;