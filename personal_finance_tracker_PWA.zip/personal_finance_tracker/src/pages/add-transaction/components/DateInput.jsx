import React from 'react';
import Input from '../../../components/ui/Input';

const DateInput = ({ date, onDateChange, error }) => {
  const formatDateForInput = (dateString) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date?.toISOString()?.split('T')?.[0];
  };

  const formatDateForDisplay = (dateString) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date?.toLocaleDateString('id-ID', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    });
  };

  const handleChange = (e) => {
    onDateChange(e?.target?.value);
  };

  return (
    <div className="space-y-2">
      <label className="block text-sm font-medium text-foreground">
        Tanggal <span className="text-error">*</span>
      </label>
      <Input
        type="date"
        value={formatDateForInput(date)}
        onChange={handleChange}
        error={error}
        required
      />
      {date && (
        <p className="text-xs text-muted-foreground">
          Format: {formatDateForDisplay(date)}
        </p>
      )}
    </div>
  );
};

export default DateInput;