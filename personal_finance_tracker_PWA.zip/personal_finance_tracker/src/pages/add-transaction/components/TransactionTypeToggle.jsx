import React from 'react';
import Button from '../../../components/ui/Button';

const TransactionTypeToggle = ({ selectedType, onTypeChange }) => {
  return (
    <div className="space-y-2">
      <label className="block text-sm font-medium text-foreground">
        Jenis Transaksi <span className="text-error">*</span>
      </label>
      <div className="grid grid-cols-2 gap-3">
        <Button
          variant={selectedType === 'income' ? 'success' : 'outline'}
          size="default"
          fullWidth
          onClick={() => onTypeChange('income')}
          iconName="TrendingUp"
          iconPosition="left"
          iconSize={18}
        >
          Pemasukan
        </Button>
        <Button
          variant={selectedType === 'expense' ? 'destructive' : 'outline'}
          size="default"
          fullWidth
          onClick={() => onTypeChange('expense')}
          iconName="TrendingDown"
          iconPosition="left"
          iconSize={18}
        >
          Pengeluaran
        </Button>
      </div>
    </div>
  );
};

export default TransactionTypeToggle;