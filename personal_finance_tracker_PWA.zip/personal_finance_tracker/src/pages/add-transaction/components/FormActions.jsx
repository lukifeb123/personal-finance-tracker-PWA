import React from 'react';
import Button from '../../../components/ui/Button';

const FormActions = ({ onSave, onCancel, isLoading, isValid }) => {
  return (
    <div className="space-y-3 pt-6">
      <Button
        variant="default"
        size="lg"
        fullWidth
        onClick={onSave}
        loading={isLoading}
        disabled={!isValid}
        iconName="Save"
        iconPosition="left"
        iconSize={18}
      >
        {isLoading ? 'Menyimpan...' : 'Simpan Transaksi'}
      </Button>
      
      <Button
        variant="outline"
        size="default"
        fullWidth
        onClick={onCancel}
        disabled={isLoading}
        iconName="X"
        iconPosition="left"
        iconSize={16}
      >
        Batal
      </Button>
    </div>
  );
};

export default FormActions;