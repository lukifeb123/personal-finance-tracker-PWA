import React from 'react';

const NotesInput = ({ notes, onNotesChange }) => {
  return (
    <div className="space-y-2">
      <label className="block text-sm font-medium text-foreground">
        Catatan
      </label>
      <textarea
        placeholder="Tambahkan catatan untuk transaksi ini (opsional)"
        value={notes}
        onChange={(e) => onNotesChange(e?.target?.value)}
        rows={3}
        className="w-full px-3 py-2 border border-border rounded-md bg-input text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent resize-none"
      />
      <p className="text-xs text-muted-foreground">
        Maksimal 200 karakter
      </p>
    </div>
  );
};

export default NotesInput;