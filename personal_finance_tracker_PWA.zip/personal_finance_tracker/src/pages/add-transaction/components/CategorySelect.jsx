import React from 'react';
import Select from '../../../components/ui/Select';

const CategorySelect = ({ selectedType, selectedCategory, onCategoryChange, error }) => {
  const incomeCategories = [
    { value: 'gaji', label: 'Gaji' },
    { value: 'bonus', label: 'Bonus' },
    { value: 'freelance', label: 'Freelance' },
    { value: 'investasi', label: 'Investasi' },
    { value: 'bisnis', label: 'Bisnis' },
    { value: 'hadiah', label: 'Hadiah' },
    { value: 'lainnya', label: 'Lainnya' }
  ];

  const expenseCategories = [
    { value: 'makanan', label: 'Makanan & Minuman' },
    { value: 'transportasi', label: 'Transportasi' },
    { value: 'belanja', label: 'Belanja' },
    { value: 'tagihan', label: 'Tagihan' },
    { value: 'kesehatan', label: 'Kesehatan' },
    { value: 'hiburan', label: 'Hiburan' },
    { value: 'pendidikan', label: 'Pendidikan' },
    { value: 'rumah', label: 'Rumah Tangga' },
    { value: 'pakaian', label: 'Pakaian' },
    { value: 'lainnya', label: 'Lainnya' }
  ];

  const categories = selectedType === 'income' ? incomeCategories : expenseCategories;

  return (
    <Select
      label="Kategori"
      placeholder="Pilih kategori"
      options={categories}
      value={selectedCategory}
      onChange={onCategoryChange}
      required
      error={error}
      searchable
    />
  );
};

export default CategorySelect;