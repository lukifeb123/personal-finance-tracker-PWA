import React from 'react';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';

const SuccessModal = ({ isOpen, onClose, onAddAnother, onViewDashboard }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <div className="bg-card rounded-lg shadow-xl max-w-sm w-full mx-4 p-6">
        <div className="text-center space-y-4">
          <div className="w-16 h-16 bg-success/10 rounded-full flex items-center justify-center mx-auto">
            <Icon name="CheckCircle" size={32} color="var(--color-success)" />
          </div>
          
          <div className="space-y-2">
            <h3 className="text-lg font-semibold text-foreground">
              Transaksi Berhasil Disimpan!
            </h3>
            <p className="text-sm text-muted-foreground">
              Transaksi Anda telah berhasil ditambahkan ke dalam catatan keuangan.
            </p>
          </div>

          <div className="space-y-3 pt-4">
            <Button
              variant="default"
              size="default"
              fullWidth
              onClick={onAddAnother}
              iconName="Plus"
              iconPosition="left"
              iconSize={16}
            >
              Tambah Transaksi Lagi
            </Button>
            
            <Button
              variant="outline"
              size="default"
              fullWidth
              onClick={onViewDashboard}
              iconName="Home"
              iconPosition="left"
              iconSize={16}
            >
              Lihat Dashboard
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SuccessModal;