import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import Icon from '../AppIcon';

const FloatingActionButton = () => {
  const location = useLocation();
  
  // Only show on Dashboard and History pages
  const shouldShow = location.pathname === '/dashboard-overview' || location.pathname === '/transaction-history';
  
  if (!shouldShow) {
    return null;
  }

  return (
    <Link
      to="/add-transaction"
      className="md:hidden fixed bottom-20 right-4 z-80 w-14 h-14 bg-primary hover:bg-primary/90 text-primary-foreground rounded-full shadow-lg hover:shadow-xl flex items-center justify-center transition-all duration-150 transform hover:scale-105 active:scale-95"
      aria-label="Tambah Transaksi"
    >
      <Icon name="Plus" size={24} color="white" />
    </Link>
  );
};

export default FloatingActionButton;