import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import Icon from '../AppIcon';

const MobileNavigation = () => {
  const location = useLocation();

  const navigationItems = [
    {
      label: 'Dashboard',
      path: '/dashboard-overview',
      icon: 'Home'
    },
    {
      label: 'Tambah',
      path: '/add-transaction',
      icon: 'Plus'
    },
    {
      label: 'Riwayat',
      path: '/transaction-history',
      icon: 'History'
    }
  ];

  const isActivePath = (path) => {
    return location.pathname === path;
  };

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-90 bg-card border-t border-border">
      <div className="flex items-center justify-around px-2 py-2">
        {navigationItems?.map((item) => (
          <Link
            key={item?.path}
            to={item?.path}
            className={`flex flex-col items-center justify-center min-w-0 flex-1 px-2 py-2 rounded-lg transition-colors duration-150 ${
              isActivePath(item?.path)
                ? 'text-primary bg-primary/10' :'text-muted-foreground hover:text-foreground hover:bg-muted'
            }`}
          >
            <Icon 
              name={item?.icon} 
              size={20} 
              className={isActivePath(item?.path) ? 'text-primary' : 'text-muted-foreground'} 
            />
            <span className={`text-xs font-medium mt-1 truncate ${
              isActivePath(item?.path) ? 'text-primary' : 'text-muted-foreground'
            }`}>
              {item?.label}
            </span>
          </Link>
        ))}
      </div>
    </nav>
  );
};

export default MobileNavigation;